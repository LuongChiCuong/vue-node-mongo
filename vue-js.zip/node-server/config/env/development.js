module.exports = {
  // Development configuration options
  db: 'mongodb://localhost/mean',
  sessionSecret: 'developmentSessionSecret'
};
