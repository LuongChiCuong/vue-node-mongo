var config = require('./config'),
    express = require('express'),
    morgan = require('morgan'),
    compress = require('compression'),
    cookieParser = require('cookie-parser'),
    bodyParser = require('body-parser'),
    methodOverride = require('method-override'),
    session = require('express-session');

module.exports = function() {
  var app = express();

  if (process.env.NODE_ENV === 'development') {
    // provide logger middleware
    app.use(morgan('dev'));
  } else if (process.env.NODE_ENV === 'production') {
    // provide response compression
    app.use(compress());
  }

  app.use(bodyParser.urlencoded({
    extended: true
  }));

  //this module provide several middleware to handle request data
  app.use(bodyParser.json());
  // this module provide DELETE and PUT HTTP vers legacy support
  app.use(methodOverride());

  app.use(session({
    saveUninitialized: true,
    resave: true,
    secret: config.sessionSecret
  }));

  require('../routes/index.route.js') (app);
  require('../routes/bookmark.route.js') (app);

  app.use(express.static('../public'));

  return app;
}
