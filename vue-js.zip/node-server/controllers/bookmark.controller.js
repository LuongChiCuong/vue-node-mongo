var Bookmark = require('mongoose').model('Bookmark');

exports.create = function(req, res, next) {
  var bm = new Bookmark(req.body);

  bm.save(function(err, result){
    console.log(err);
    console.log(bm);
      if (err) {
        console.log('error');
        return next(err);
      } else {
        console.log('save success');
        res.json(result);
      }
  });

}

exports.find = function(req, res, next) {
  console.log('find feature');
  Bookmark.find(function (err, bms) {
    if (err) return console.error(err);
    console.log(bms);
  })
}
