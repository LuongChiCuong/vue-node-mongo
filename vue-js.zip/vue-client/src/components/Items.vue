<template>
  <ul>
    <li v-for="bm in bookmarks">
      {{ bm.name }}
    </li>
  </ul>
</template>

<script>
let items = [
  {name: 'Google'},
  {name: 'Bing'},
  {name: 'Vue JS'}
]

export default {
  name: 'items',
  data () {
    return {
      bookmarks: items
    }
  }
}
</script>
