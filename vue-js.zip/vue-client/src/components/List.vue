<template>
  <div>
    <h1> {{subject}} </h1>
    <items></items>
  </div>
</template>

<script>
import Items from './Items'

export default {
  name: 'list',
  components: {
    Items
  },
  data () {
    return {
      subject: 'This is My Bookmark Collection'
    }
  }
}
</script>
